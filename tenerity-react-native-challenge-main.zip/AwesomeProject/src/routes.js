import React from 'react'
import { Router, Scene } from 'react-native-router-flux'
import Home from './offerList'
import offerDetail from './offerDetail'

const Routes = () => (
   <Router>
      <Scene key = "root">
         <Scene key = "home" component = {Home} title = "offersList" initial = {true} />
         <Scene key = "about" component = {offerDetail} title = "offerDetail" />
      </Scene>
   </Router>
)
export default Routes