import React, { Component } from 'react'
import {Text,View,Image,Dimensions,ScrollView} from 'react-native'

export default class offerDetail extends Component {
    constructor(props){
        super()
    }
    renderDetail(){
        let dom = 'offerType : ' + this.props.offerType + '\n';
        dom += 'description : ' + this.props.description + '\n';
        dom += 'price : ' + this.props.price + '\n';

        return dom;
    }
    render() {
        let viewWidth = Dimensions.get('window').width;
        return (
            <View>
                <ScrollView>
                    <Image style={{width:viewWidth,height:viewWidth}} source={{uri: this.props.image}}></Image>
                    <Text style={{fontSize : 25}}>
                        {this.renderDetail()}
                    </Text>
                </ScrollView>
            </View>
        )
    }
}
